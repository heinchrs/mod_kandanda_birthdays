<?php
/**
* Moduele mod_kandanda_birthdays J!2.5
* @version    : siehe mod_kandanda_birthdays.php
* @package    : Joomla 2.5 - Module
* @license    : GNU General Public License version 2 or later
* @copyright  : (C) 2013 by Alexander Groezinger - All rights reserved!
* @website    : http://www.joomext.de.vu
*
*/

defined('_JEXEC') or die;
?>

<!-- Beginn Kandanda Birthdays -->
<div id="kandanda_birthdays_container">
<?php
	if(count($data) > 0) {
		foreach ($data as $entry) :
?>
	<div class="birthday_entry">
		<span class="birthday_name"><?php echo $entry['title']; ?></span>
		<span class="birthday_date"><?php echo $entry['value']; ?> (<?php echo $entry['wird_x_jahre']; ?>)</span>
	</div>
<?php
		endforeach;
	} else {
		echo '<div class="no_data">Es stehen keine Geburtstage an</div>';
	}
?>
</div>
<!-- Ende Kandanda Birthdays -->